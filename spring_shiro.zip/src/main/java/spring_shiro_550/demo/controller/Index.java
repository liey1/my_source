package spring_shiro_550.demo.controller;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.crypto.hash.Md5Hash;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import org.apache.shiro.subject.Subject;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import java.util.Map;

@Controller
public class Index {

    @RequestMapping("/login")
    public String login(Map<String, Object> map, @RequestParam(required = false) String username, @RequestParam(required = false) String password) {
        if (username != null && password != null) {
            try {
                Subject subject = SecurityUtils.getSubject();
                subject.login(new UsernamePasswordToken(username, password,true));
                return "redirect:/myInfo";
            } catch (UnknownAccountException e) {
                map.put("msg", "喜喜");
            }
        }
        return "/login";
    }

    @RequestMapping("/403")
    public String unauth(HttpServletRequest request, Map<String, Object> map) {
        return "/403";
    }
}
