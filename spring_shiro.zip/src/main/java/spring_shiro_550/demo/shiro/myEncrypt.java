package spring_shiro_550.demo.shiro;

import org.apache.shiro.codec.Base64;
import org.apache.shiro.crypto.AesCipherService;
import org.apache.shiro.util.ByteSource;
import org.apache.shiro.web.mgt.CookieRememberMeManager;

public class myEncrypt {

    static  byte[]  cipher_key = Base64.decode("kPH+bIxk5D2deZiIxcaaaA==");

    void myEncrypt(){

    }

    public static String encrypt(byte[] b) {

        AesCipherService aesCipherService = new AesCipherService();
        ByteSource cipher = aesCipherService.encrypt(b, cipher_key);
        return Base64.encodeToString(cipher.getBytes());
    }
}
