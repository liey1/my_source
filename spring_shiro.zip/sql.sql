insert into user_info(id,username,password,salt) values(999,'admin','8e6adf82e890e2e93b55a43cdaa1920c','a');
insert into user_info(id,username,password,salt) values(998,'ruozhi','8e6adf82e890e2e93b55a43cdaa1920c','a');

insert into user_permission(id,name,url,description) values(1,"admin:listAll","/userList","admin列全部用户");
insert into user_permission(id,name,url,description) values(2,"admin:listByName","/userList","admin指定用户");
insert into user_permission(id,name,url,description) values(3,"user:showMyInfo","/myInfo","用户列自己的信息");

insert into sys_role(id,name,description) values(1,"admin","管理员");
insert into sys_role(id,name,description) values(2,"user","普通用户");

insert into user_role_permission(role_id,permissions_id) values(1,1);
insert into user_role_permission(role_id,permissions_id) values(1,2);
insert into user_role_permission(role_id,permissions_id) values(2,3);

insert into sys_user_role(uid,role_id) values(999,1);
insert into sys_user_role(uid,role_id) values(999,2);
insert into sys_user_role(uid,role_id) values(998,2);




